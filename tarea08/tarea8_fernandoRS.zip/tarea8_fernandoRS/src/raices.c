#include "raices.h"

double NRmethod(double x0, int iter, double err){

return 0.0;}


