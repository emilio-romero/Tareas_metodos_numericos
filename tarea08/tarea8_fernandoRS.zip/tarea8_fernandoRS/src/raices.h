#ifndef RAICES_H
#define RAICES_H 
#include <stdio.h> 
#include <stdlib.h> 
#include <math.h> 
#include <float.h> 

double NRmethod(double x0, int iter, double err);

#endif 
